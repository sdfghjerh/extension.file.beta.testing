# Supabase Auth - Chrome Extension

Change your Supabase details in bg-supa.js and manifest.json to fit your Supabase API details.
